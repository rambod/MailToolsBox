from MailToolsBox.mailSender import SendAgent
from MailToolsBox.imapClient import ImapAgent
